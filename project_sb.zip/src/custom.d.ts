declare module "*.jpg";
declare module "*.png";
declare module "*.jpeg";
declare module "*.gif";
declare module "@fortawesome/free-solid-svg-icons";

interface Window {
  Kakao: any;
}
