import React from "react";

const myCalendarUpdateModal = () => {
  return <div>myCalendarUpdateModal</div>;
};

export default myCalendarUpdateModal;
