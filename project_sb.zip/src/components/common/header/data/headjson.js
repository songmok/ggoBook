export const navheader = [
  { id: "1", to: "/mycalendar", name: "나의 책장", icon: "book-open" },
  { id: "2", to: "/rank", name: "마라톤", icon: "person-running" },
  { id: "3", to: "/book", name: "도서", icon: "book" },
  { id: "4", to: "/event", name: "이벤트", icon: "calendar-day" },
  { id: "5", to: "/mypage", name: "마이 페이지", icon: "user" },
];
