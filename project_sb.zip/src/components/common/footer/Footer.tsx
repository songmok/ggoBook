import FooterCss from "./style/FooterCss";

type Props = {};

const Footer = (props: Props) => {
  return <FooterCss>Footer</FooterCss>;
};

export default Footer;
