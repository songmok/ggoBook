export const rankgrid = `
display: grid;
grid-template-columns: repeat(4, 1fr);
justify-items: center;
`;
export const sectionwrap = `
margin: 0 100px;
padding-top: 50px;
`;
