import styled from "styled-components";

const NotFoundCss = styled.section``;

export default NotFoundCss;
