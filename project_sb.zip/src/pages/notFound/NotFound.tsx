import React from "react";
import NotFoundCss from "./style/NotFoundCss";

const NotFound = () => {
  return <NotFoundCss>NotFound Error</NotFoundCss>;
};

export default NotFound;
