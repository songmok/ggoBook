export const minsize = "1.2rem"; // 12px
export const defaltsize = "1.6rem"; // 16px
export const midllesize = "2rem"; // 20px
export const bigsize = "2.4rem"; // 24px
export const headertitle = "4rem"; // 40px
export const headerIcon = "5rem"; // 60px
