export const rankhead = [
  { id: "1", name: "등수" },
  { id: "2", name: "독서가" },
  { id: "3", name: "페이지 수" },
  { id: "4", name: "포인트" },
];
export const rankuser = [
  { name: "1", dd: "Ssd", pag: "1345", pit: "123" },
  { name: "2", dd: "G", pag: "1345", pit: "123" },
  { name: "3", dd: "A", pag: "1345", pit: "123" },
  { name: "4", dd: "S", pag: "1345", pit: "123" },
  { name: "5", dd: "D", pag: "1345", pit: "123" },
  { name: "6", dd: "D", pag: "1345", pit: "123" },
  { name: "7", dd: "D", pag: "1345", pit: "123" },
  { name: "8", dd: "D", pag: "1345", pit: "123" },
  { name: "9", dd: "D", pag: "1345", pit: "123" },
  { name: "10", dd: "D", pag: "1345", pit: "123" },
];
