import styled from "styled-components";

export const MyCalendarCss = styled.section`
  display: flex;
  padding-left: 2rem;
  padding-right: 2rem;

  .fullcalendarWrap {
    /* width: 100%; */
    .fc {
      /* display: block; */
    }
  }
`;
